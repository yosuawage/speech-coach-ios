import SwiftUI

@main
struct ElsaSpeechApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
