import Foundation

public enum PhonemeCategory: String, CaseIterable, Codable {
    case shortVowels = "Short Vowels"
    case longVowels = "Long Vowels"
    case diphthongs = "Diphthongs"
    case consonants = "Consonants"
}

public struct PhonemeItem: Identifiable, Codable {
    public let id: String
    public let symbol: String // e.g. "/æ/"
    public let code: String // e.g. "ae"
    public let exampleWord: String // e.g. "Cat"
    public let exampleIPA: String // e.g. "/kæt/"
    public let tip: String
    public let category: PhonemeCategory
    
    public init(id: String, symbol: String, code: String, exampleWord: String, exampleIPA: String, tip: String, category: PhonemeCategory) {
        self.id = id
        self.symbol = symbol
        self.code = code
        self.exampleWord = exampleWord
        self.exampleIPA = exampleIPA
        self.tip = tip
        self.category = category
    }
}
