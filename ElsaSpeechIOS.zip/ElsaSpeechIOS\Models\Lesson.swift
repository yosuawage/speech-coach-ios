import Foundation

public enum LessonDifficulty: String, Codable {
    case beginner = "Beginner"
    case intermediate = "Intermediate"
    case advanced = "Advanced"
}

public struct PhonemeSegment: Identifiable, Codable {
    public var id = UUID()
    public let text: String
    public let ipa: String
    public var score: Int = 0 // 0 to 100
    
    public init(text: String, ipa: String, score: Int = 0) {
        self.text = text
        self.ipa = ipa
        self.score = score
    }
}

public struct ExerciseItem: Identifiable, Codable {
    public let id: String
    public let targetText: String
    public let ipaTranscription: String
    public let translationId: String
    public let focusPhoneme: String
    public let segments: [PhonemeSegment]
    
    public init(id: String, targetText: String, ipaTranscription: String, translationId: String, focusPhoneme: String, segments: [PhonemeSegment]) {
        self.id = id
        self.targetText = targetText
        self.ipaTranscription = ipaTranscription
        self.translationId = translationId
        self.focusPhoneme = focusPhoneme
        self.segments = segments
    }
}

public struct Lesson: Identifiable, Codable {
    public let id: String
    public let title: String
    public let subtitle: String
    public let iconName: String
    public let difficulty: LessonDifficulty
    public let exercises: [ExerciseItem]
    
    public init(id: String, title: String, subtitle: String, iconName: String, difficulty: LessonDifficulty, exercises: [ExerciseItem]) {
        self.id = id
        self.title = title
        self.subtitle = subtitle
        self.iconName = iconName
        self.difficulty = difficulty
        self.exercises = exercises
    }
}

public struct PronunciationScore {
    public let overallScore: Int // 0-100
    public let recognizedText: String
    public let targetText: String
    public let feedbackMessage: String
    public let wordBreakdown: [(word: String, isCorrect: Bool, score: Int)]
    
    public var feedbackColor: String {
        if overallScore >= 80 { return "green" }
        if overallScore >= 50 { return "orange" }
        return "red"
    }
}
