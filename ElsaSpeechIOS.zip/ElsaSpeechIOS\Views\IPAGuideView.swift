import SwiftUI

public struct IPAGuideView: View {
    @StateObject private var audioPlayer = AudioPlayerManager.shared
    @State private var selectedCategory: PhonemeCategory = .shortVowels
    
    public var filteredPhonemes: [PhonemeItem] {
        SampleData.samplePhonemes.filter { $0.category == selectedCategory }
    }
    
    public init() {}
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                // Segmented Control
                Picker("Kategori", selection: $selectedCategory) {
                    ForEach(PhonemeCategory.allCases, id: \.self) { category in
                        Text(category.rawValue).tag(category)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                
                // Phoneme Grid
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                        ForEach(filteredPhonemes) { item in
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    Text(item.symbol)
                                        .font(.system(size: 28, weight: .bold, design: .serif))
                                        .foregroundColor(.blue)
                                    Spacer()
                                    Button(action: {
                                        audioPlayer.speak(text: item.exampleWord, rate: 0.35)
                                    }) {
                                        Image(systemName: "speaker.wave.2.circle.fill")
                                            .font(.system(size: 28))
                                            .foregroundColor(.indigo)
                                    }
                                }
                                
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.exampleWord)
                                        .font(.headline)
                                    Text(item.exampleIPA)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                
                                Text(item.tip)
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                                    .lineLimit(3)
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color(UIColor.secondarySystemBackground))
                            )
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 8)
                }
            }
            .navigationTitle("Tabel Fonetik (IPA)")
        }
    }
}
