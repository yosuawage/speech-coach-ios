import SwiftUI

public struct ContentView: View {
    @State private var selectedTab: Int = 0
    let lessons = SampleData.sampleLessons
    
    public init() {}
    
    public var body: some View {
        TabView(selection: $selectedTab) {
            // Tab 1: Lessons
            NavigationView {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Banner Card
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text("Latihan Harian")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 4)
                                    .background(Color.white.opacity(0.25))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                                Spacer()
                                Image(systemName: "flame.fill")
                                    .foregroundColor(.orange)
                                Text("Streak: 3 Hari")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                            }
                            
                            Text("Tingkatkan Akurasi Pengucapan Bahasa Inggris")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text("Fokus hari ini: Fonem /θ/ dan intonasi kalimat tanya.")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.85))
                        }
                        .padding()
                        .background(
                            LinearGradient(gradient: Gradient(colors: [Color.blue, Color.indigo]), startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .cornerRadius(20)
                        .padding(.horizontal)
                        
                        // Lesson List Section
                        Text("Daftar Modul Belajar")
                            .font(.title2)
                            .fontWeight(.bold)
                            .padding(.horizontal)
                        
                        ForEach(lessons) { lesson in
                            NavigationLink(destination: LessonView(lesson: lesson)) {
                                HStack(spacing: 16) {
                                    Image(systemName: lesson.iconName)
                                        .font(.system(size: 26))
                                        .foregroundColor(.blue)
                                        .frame(width: 50, height: 50)
                                        .background(Color.blue.opacity(0.12))
                                        .cornerRadius(14)
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(lesson.title)
                                            .font(.headline)
                                            .foregroundColor(.primary)
                                        Text(lesson.subtitle)
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                        
                                        HStack {
                                            Text(lesson.difficulty.rawValue)
                                                .font(.caption2)
                                                .padding(.horizontal, 8)
                                                .padding(.vertical, 2)
                                                .background(Color.gray.opacity(0.15))
                                                .cornerRadius(6)
                                                .foregroundColor(.secondary)
                                            
                                            Text("\(lesson.exercises.count) Latihan")
                                                .font(.caption2)
                                                .foregroundColor(.secondary)
                                        }
                                        .padding(.top, 2)
                                    }
                                    
                                    Spacer()
                                    
                                    Image(systemName: "chevron.right")
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundColor(.secondary)
                                }
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 16)
                                        .fill(Color(UIColor.secondarySystemBackground))
                                )
                                .padding(.horizontal)
                            }
                        }
                    }
                    .padding(.vertical)
                }
                .navigationTitle("Speech Coach")
            }
            .tabItem {
                Label("Belajar", systemImage: "book.fill")
            }
            .tag(0)
            
            // Tab 2: IPA Chart
            IPAGuideView()
                .tabItem {
                    Label("Suara IPA", systemImage: "waveform")
                }
                .tag(1)
            
            // Tab 3: About / Settings
            NavigationView {
                List {
                    Section(header: Text("Tentang Aplikasi")) {
                        HStack {
                            Text("Versi")
                            Spacer()
                            Text("1.0.0 (Native iOS)")
                                .foregroundColor(.secondary)
                        }
                        HStack {
                            Text("Engine Speech")
                            Spacer()
                            Text("Apple Speech Framework")
                                .foregroundColor(.secondary)
                        }
                        HStack {
                            Text("Audio Engine")
                            Spacer()
                            Text("AVAudioEngine + TTS")
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Section(header: Text("Panduan Izin")) {
                        Text("Pastikan izin Mikrofon dan Speech Recognition diizinkan di Pengaturan iPhone agar deteksi suara dapat berfungsi dengan akurat.")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                }
                .navigationTitle("Pengaturan")
            }
            .tabItem {
                Label("Pengaturan", systemImage: "gearshape.fill")
            }
            .tag(2)
        }
    }
}
