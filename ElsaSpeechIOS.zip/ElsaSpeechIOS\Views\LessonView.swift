import SwiftUI

public struct LessonView: View {
    public let lesson: Lesson
    @State private var currentExerciseIndex: Int = 0
    @StateObject private var speechManager = SpeechManager.shared
    @StateObject private var audioPlayer = AudioPlayerManager.shared
    @State private var isShowingResult: Bool = false
    
    public var currentExercise: ExerciseItem {
        lesson.exercises[currentExerciseIndex]
    }
    
    public init(lesson: Lesson) {
        self.lesson = lesson
    }
    
    public var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // Header Progress
                HStack {
                    Text("Latihan \(currentExerciseIndex + 1) dari \(lesson.exercises.count)")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Spacer()
                    Text(currentExercise.focusPhoneme)
                        .font(.caption)
                        .fontWeight(.bold)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.blue.opacity(0.15))
                        .foregroundColor(.blue)
                        .cornerRadius(12)
                }
                .padding(.horizontal)
                
                // Progress Bar
                ProgressView(value: Double(currentExerciseIndex + 1), total: Double(lesson.exercises.count))
                    .accentColor(.blue)
                    .padding(.horizontal)
                
                // Target Card
                VStack(spacing: 16) {
                    Text(currentExercise.targetText)
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.primary)
                    
                    Text(currentExercise.ipaTranscription)
                        .font(.system(size: 20, weight: .medium, design: .monospaced))
                        .foregroundColor(.blue)
                    
                    Text("\"\(currentExercise.translationId)\"")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .italic()
                    
                    // Listen Button
                    Button(action: {
                        audioPlayer.speak(text: currentExercise.targetText)
                    }) {
                        HStack(spacing: 8) {
                            Image(systemName: audioPlayer.isSpeaking ? "speaker.wave.3.fill" : "speaker.wave.2")
                            Text(audioPlayer.isSpeaking ? "Mendengarkan..." : "Dengarkan Contoh")
                                .fontWeight(.semibold)
                        }
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(Color.indigo)
                        .cornerRadius(24)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 32)
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color(UIColor.secondarySystemBackground))
                        .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 4)
                )
                .padding(.horizontal)
                
                // Spoken Transcription Real-time preview
                if speechManager.isRecording || !speechManager.recognizedText.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Suara Anda:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Text(speechManager.recognizedText.isEmpty ? "Mendengarkan suara Anda..." : speechManager.recognizedText)
                            .font(.headline)
                            .foregroundColor(speechManager.isRecording ? .blue : .primary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.blue.opacity(0.08))
                    .cornerRadius(12)
                    .padding(.horizontal)
                }
                
                // Score Result Card
                if let score = speechManager.latestScore {
                    VStack(spacing: 16) {
                        HStack(spacing: 16) {
                            ZStack {
                                Circle()
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 8)
                                    .frame(width: 72, height: 72)
                                Circle()
                                    .trim(from: 0, to: CGFloat(score.overallScore) / 100.0)
                                    .stroke(score.overallScore >= 75 ? Color.green : (score.overallScore >= 50 ? Color.orange : Color.red), style: StrokeStyle(lineWidth: 8, lineCap: .round))
                                    .rotationEffect(.degrees(-90))
                                    .frame(width: 72, height: 72)
                                Text("\(score.overallScore)%")
                                    .font(.headline)
                                    .fontWeight(.bold)
                            }
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text(score.overallScore >= 75 ? "Sangat Bagus!" : (score.overallScore >= 50 ? "Hampir Benar" : "Perlu Diperbaiki"))
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .foregroundColor(score.overallScore >= 75 ? .green : (score.overallScore >= 50 ? .orange : .red))
                                
                                Text(score.feedbackMessage)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                        }
                        
                        // Word by word feedback
                        if !score.wordBreakdown.isEmpty {
                            Divider()
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Detail Kata:")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.secondary)
                                
                                HStack(spacing: 8) {
                                    ForEach(score.wordBreakdown.indices, id: \.self) { idx in
                                        let item = score.wordBreakdown[idx]
                                        VStack(spacing: 2) {
                                            Text(item.word)
                                                .font(.subheadline)
                                                .fontWeight(.bold)
                                                .foregroundColor(item.isCorrect ? .green : .red)
                                            Text("\(item.score)%")
                                                .font(.caption2)
                                                .foregroundColor(.secondary)
                                        }
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(item.isCorrect ? Color.green.opacity(0.12) : Color.red.opacity(0.12))
                                        .cornerRadius(8)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(UIColor.systemBackground))
                            .shadow(color: Color.black.opacity(0.06), radius: 8, x: 0, y: 3)
                    )
                    .padding(.horizontal)
                }
                
                Spacer(minLength: 20)
                
                // Control Buttons
                VStack(spacing: 14) {
                    // Microphone button
                    Button(action: {
                        if speechManager.isRecording {
                            speechManager.stopRecording(targetText: currentExercise.targetText)
                        } else {
                            do {
                                try speechManager.startRecording(targetText: currentExercise.targetText)
                            } catch {
                                print("Recording error: \(error)")
                            }
                        }
                    }) {
                        ZStack {
                            Circle()
                                .fill(speechManager.isRecording ? Color.red : Color.blue)
                                .frame(width: 80, height: 80)
                                .shadow(color: (speechManager.isRecording ? Color.red : Color.blue).opacity(0.4), radius: 10, x: 0, y: 5)
                            
                            Image(systemName: speechManager.isRecording ? "stop.fill" : "mic.fill")
                                .font(.system(size: 32, weight: .bold))
                                .foregroundColor(.white)
                        }
                    }
                    
                    Text(speechManager.isRecording ? "Ketuk tombol merah jika selesai berbicara" : "Tekan mikrofon & ucapkan kalimat di atas")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    // Next Button
                    if speechManager.latestScore != nil && currentExerciseIndex < lesson.exercises.count - 1 {
                        Button(action: {
                            currentExerciseIndex += 1
                            speechManager.latestScore = nil
                            speechManager.recognizedText = ""
                        }) {
                            HStack {
                                Text("Latihan Selanjutnya")
                                    .fontWeight(.bold)
                                Image(systemName: "arrow.right")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(14)
                        }
                        .padding(.horizontal)
                        .padding(.top, 10)
                    }
                }
                .padding(.bottom, 24)
            }
            .padding(.top)
        }
        .navigationTitle(lesson.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
