# Panduan Instalasi Aplikasi Speech Coach ke iPhone dari Windows

Aplikasi **Speech Coach iOS** telah selesai dibuat menggunakan arsitektur **Native SwiftUI** dengan integrasi **Apple Speech Framework & AVAudioEngine**.

---

## 📱 Ringkasan Fitur yang Sudah Terpasang:
1. **Modul Latihan Pengucapan (Lesson View):**
   - Transkripsi fonetik standar **IPA** (*International Phonetic Alphabet*).
   - Tombol **Dengarkan Contoh** menggunakan aksen Native American English (`en-US`).
   - Perekaman mikrofon interaktif real-time.
   - **Evaluasi Kemiripan & Skor Akurasi (0–100%)** otomatis dengan feedback per kata (Hijau = Bagus, Oranye = Hampir Benar, Merah = Perlu Diperbaiki).
2. **Tabel Suara Fonetik (IPA Guide):**
   - Daftar vokal pendek, vokal panjang, diftong, dan konsonan (`/θ/`, `/ð/`, `/æ/`, `/iː/`, dll.) yang dapat ditekan untuk mendengarkan lafal dan membaca tips penempatan lidah/bibir.
3. **Desain Bersih & Legal:**
   - 100% Native iOS tanpa ketergantungan library proprietary yang melanggar hak cipta.

---

## 🚀 Cara Memasang Aplikasi ke iPhone Anda dari Windows

Karena Anda menggunakan Windows, Apple tidak mengizinkan kompilasi langsung tanpa macOS. Namun, Anda dapat memasang aplikasi ini ke iPhone menggunakan **2 metode mudah** berikut:

---

### METODE 1: Sideloading via Sideloadly (Rekomendasi dari Windows)

Jika Anda sudah memiliki file `ElsaSpeechIOS.ipa` (dari hasil build Metode 2):

1. **Unduh Sideloadly di Windows:**
   - Kunjungi situs resmi: [https://sideloadly.io](https://sideloadly.io) dan instal di komputer Anda.
   - Pastikan **iTunes** dan **iCloud** (versi non-Microsoft Store) sudah terpasang agar driver iPhone terdeteksi.
2. **Hubungkan iPhone ke PC:**
   - Sambungkan iPhone ke PC Windows dengan kabel Lightning/USB-C.
   - Pada layar iPhone, pilih **"Trust This Computer"** (Percayai Komputer Ini).
3. **Pasang File IPA:**
   - Buka Sideloadly di PC.
   - *Drag and drop* file `ElsaSpeechIOS.ipa` ke dalam Sideloadly.
   - Masukkan Apple ID pribadi Anda (digunakan untuk menandatangani sertifikat gratis Apple 7 hari).
   - Klik **Start**.
4. **Izinkan Aplikasi di iPhone:**
   - Setelah selesai, ikon aplikasi akan muncul di layar iPhone Anda.
   - Sebelum membuka, buka menu di iPhone:  
     `Settings (Pengaturan)` $\rightarrow$ `General (Umum)` $\rightarrow$ `VPN & Device Management` $\rightarrow$ Ketuk Apple ID Anda $\rightarrow$ Ketuk **Trust (Percayai)**.
   - Sekarang aplikasi siap digunakan di iPhone Anda!

---

### METODE 2: Build IPA Gratis di Cloud Menggunakan GitHub Actions (Tanpa Mac)

Proyek ini telah dilengkapi file otomasi build di [`.github/workflows/build-ios.yml`](.github/workflows/build-ios.yml).

1. Buat repositori baru di akun [GitHub](https://github.com) Anda (bisa disetel *Private*).
2. Upload/push seluruh isi folder `ElsaSpeechIOS` ke repositori tersebut.
3. Buka tab **Actions** di repositori GitHub Anda.
4. Workflow **Build iOS IPA** akan berjalan otomatis di server macOS cloud milik GitHub.
5. Setelah build selesai (sekitar 2–3 menit), unduh file `ElsaSpeechIOS.ipa` dari bagian **Artifacts**.
6. Gunakan **Metode 1 (Sideloadly)** untuk memasangnya ke iPhone.

---

### METODE 3: Jika Anda Memiliki Akses ke Komputer Mac

1. Salin folder `ElsaSpeechIOS` ke Mac.
2. Klik dua kali pada `ElsaSpeechIOS.xcodeproj` untuk membukanya di **Xcode**.
3. Sambungkan iPhone Anda ke Mac.
4. Pilih iPhone Anda pada daftar perangkat target di toolbar atas.
5. Tekan tombol **Play (Run)**. Xcode akan mengompilasi dan menginstalnya langsung ke iPhone Anda secara otomatis.
