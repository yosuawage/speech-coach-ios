import Foundation

public struct SampleData {
    public static let samplePhonemes: [PhonemeItem] = [
        PhonemeItem(id: "p1", symbol: "/æ/", code: "ae", exampleWord: "Apple, Cat", exampleIPA: "/ˈæp.əl/", tip: "Buka mulut lebar seperti tersenyum dan turunkan rahang ke bawah.", category: .shortVowels),
        PhonemeItem(id: "p2", symbol: "/iː/", code: "iy", exampleWord: "Sheep, Read", exampleIPA: "/ʃiːp/", tip: "Tarik sudut bibir ke samping seperti tersenyum lebar, tahan suara vokal panjang.", category: .longVowels),
        PhonemeItem(id: "p3", symbol: "/ɪ/", code: "ih", exampleWord: "Ship, Sit", exampleIPA: "/ʃɪp/", tip: "Suara rileks dan pendek, berbeda dengan vokal panjang /iː/.", category: .shortVowels),
        PhonemeItem(id: "p4", symbol: "/θ/", code: "th", exampleWord: "Think, Path", exampleIPA: "/θɪŋk/", tip: "Letakkan ujung lidah di antara gigi atas dan bawah, tiupkan udara tanpa getaran pita suara (unvoiced).", category: .consonants),
        PhonemeItem(id: "p5", symbol: "/ð/", code: "dh", exampleWord: "This, Mother", exampleIPA: "/ðɪs/", tip: "Sama seperti /θ/, namun getarkan pita suara Anda saat mengeluarkan udara (voiced).", category: .consonants),
        PhonemeItem(id: "p6", symbol: "/eɪ/", code: "ey", exampleWord: "Day, Great", exampleIPA: "/deɪ/", tip: "Diftong geser: mulai dari /e/ dan akhiri ke suara /ɪ/ secara halus.", category: .diphthongs),
        PhonemeItem(id: "p7", symbol: "/aʊ/", code: "aw", exampleWord: "Now, House", exampleIPA: "/haʊs/", tip: "Mulai dari vokal terbuka /a/ lalu bulatkan bibir menuju /ʊ/.", category: .diphthongs),
        PhonemeItem(id: "p8", symbol: "/ʃ/", code: "sh", exampleWord: "Shop, Wish", exampleIPA: "/ʃɑːp/", tip: "Moncongkan bibir sedikit dan keluarkan desis udara lembut.", category: .consonants)
    ]
    
    public static let sampleLessons: [Lesson] = [
        Lesson(
            id: "les_1",
            title: "Mastering the 'TH' Sounds",
            subtitle: "Latihan pembeda suara /θ/ dan /ð/",
            iconName: "waveform.and.mic",
            difficulty: .beginner,
            exercises: [
                ExerciseItem(
                    id: "ex_1_1",
                    targetText: "Thank you",
                    ipaTranscription: "/ˈθæŋk juː/",
                    translationId: "Terima kasih",
                    focusPhoneme: "/θ/",
                    segments: [
                        PhonemeSegment(text: "Thank", ipa: "/θæŋk/"),
                        PhonemeSegment(text: "you", ipa: "/juː/")
                    ]
                ),
                ExerciseItem(
                    id: "ex_1_2",
                    targetText: "Think positive",
                    ipaTranscription: "/θɪŋk ˈpɑː.zə.t̬ɪv/",
                    translationId: "Berpikir positif",
                    focusPhoneme: "/θ/",
                    segments: [
                        PhonemeSegment(text: "Think", ipa: "/θɪŋk/"),
                        PhonemeSegment(text: "positive", ipa: "/ˈpɑː.zə.t̬ɪv/")
                    ]
                ),
                ExerciseItem(
                    id: "ex_1_3",
                    targetText: "This and that",
                    ipaTranscription: "/ðɪs ænd ðæt/",
                    translationId: "Ini dan itu",
                    focusPhoneme: "/ð/",
                    segments: [
                        PhonemeSegment(text: "This", ipa: "/ðɪs/"),
                        PhonemeSegment(text: "and", ipa: "/ænd/"),
                        PhonemeSegment(text: "that", ipa: "/ðæt/")
                    ]
                )
            ]
        ),
        Lesson(
            id: "les_2",
            title: "Tricky Vowels: /æ/ vs /e/",
            subtitle: "Membedakan kata seperti 'Cat' dan 'Bed'",
            iconName: "mouth.fill",
            difficulty: .intermediate,
            exercises: [
                ExerciseItem(
                    id: "ex_2_1",
                    targetText: "Black cat",
                    ipaTranscription: "/blæk kæt/",
                    translationId: "Kucing hitam",
                    focusPhoneme: "/æ/",
                    segments: [
                        PhonemeSegment(text: "Black", ipa: "/blæk/"),
                        PhonemeSegment(text: "cat", ipa: "/kæt/")
                    ]
                ),
                ExerciseItem(
                    id: "ex_2_2",
                    targetText: "Red bed",
                    ipaTranscription: "/red bed/",
                    translationId: "Tempat tidur merah",
                    focusPhoneme: "/e/",
                    segments: [
                        PhonemeSegment(text: "Red", ipa: "/red/"),
                        PhonemeSegment(text: "bed", ipa: "/bed/")
                    ]
                )
            ]
        ),
        Lesson(
            id: "les_3",
            title: "Everyday English Fluency",
            subtitle: "Kalimat sehari-hari dengan intonasi natural",
            iconName: "person.wave.2.fill",
            difficulty: .intermediate,
            exercises: [
                ExerciseItem(
                    id: "ex_3_1",
                    targetText: "How are you doing today?",
                    ipaTranscription: "/haʊ ɑːr juː ˈduː.ɪŋ təˈdeɪ/",
                    translationId: "Bagaimana kabarmu hari ini?",
                    focusPhoneme: "Intonation",
                    segments: [
                        PhonemeSegment(text: "How are you", ipa: "/haʊ ɑːr juː/"),
                        PhonemeSegment(text: "doing today", ipa: "/ˈduː.ɪŋ təˈdeɪ/")
                    ]
                ),
                ExerciseItem(
                    id: "ex_3_2",
                    targetText: "I would like a cup of coffee",
                    ipaTranscription: "/aɪ wʊd laɪk ə kʌp əv ˈkɑː.fi/",
                    translationId: "Saya ingin secangkir kopi",
                    focusPhoneme: "Connected Speech",
                    segments: [
                        PhonemeSegment(text: "I would like", ipa: "/aɪ wʊd laɪk/"),
                        PhonemeSegment(text: "a cup of coffee", ipa: "/ə kʌp əv ˈkɑː.fi/")
                    ]
                )
            ]
        )
    ]
}
