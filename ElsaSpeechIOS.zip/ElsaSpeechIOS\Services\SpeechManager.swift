import Foundation
import Speech
import AVFoundation

public class SpeechManager: ObservableObject {
    public static let shared = SpeechManager()
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    @Published public var isRecording: Bool = false
    @Published public var recognizedText: String = ""
    @Published public var isAuthorized: Bool = false
    @Published public var latestScore: PronunciationScore?
    @Published public var errorMessage: String?
    
    public init() {
        requestAuthorization()
    }
    
    public func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            DispatchQueue.main.async {
                switch authStatus {
                case .authorized:
                    AVAudioSession.sharedInstance().requestRecordPermission { granted in
                        DispatchQueue.main.async {
                            self.isAuthorized = granted
                        }
                    }
                default:
                    self.isAuthorized = false
                }
            }
        }
    }
    
    public func startRecording(targetText: String) throws {
        // Reset previous state
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        recognizedText = ""
        latestScore = nil
        errorMessage = nil
        
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.playAndRecord, mode: .measurement, options: [.defaultToSpeaker, .allowBluetooth])
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw NSError(domain: "SpeechManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Unable to create recognition request"])
        }
        recognitionRequest.shouldReportPartialResults = true
        
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        inputNode.removeTap(onBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            recognitionRequest.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
        
        isRecording = true
        
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }
            
            if let result = result {
                DispatchQueue.main.async {
                    self.recognizedText = result.bestTranscription.formattedString
                }
            }
            
            if error != nil || (result?.isFinal ?? false) {
                DispatchQueue.main.async {
                    self.evaluatePronunciation(targetText: targetText, spokenText: self.recognizedText)
                }
            }
        }
    }
    
    public func stopRecording(targetText: String) {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
            recognitionRequest?.endAudio()
            isRecording = false
            
            // Give speech recognizer a moment to finish, then evaluate
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.evaluatePronunciation(targetText: targetText, spokenText: self.recognizedText)
            }
        }
    }
    
    public func evaluatePronunciation(targetText: String, spokenText: String) {
        let cleanTarget = targetText.lowercased().trimmingCharacters(in: .punctuationCharacters)
        let cleanSpoken = spokenText.lowercased().trimmingCharacters(in: .punctuationCharacters)
        
        if cleanSpoken.isEmpty {
            self.latestScore = PronunciationScore(
                overallScore: 0,
                recognizedText: "Tidak ada suara terdeteksi",
                targetText: targetText,
                feedbackMessage: "Coba ucapkan lebih dekat ke mikrofon dengan artikulasi jelas.",
                wordBreakdown: []
            )
            return
        }
        
        let targetWords = cleanTarget.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        let spokenWords = cleanSpoken.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        
        var breakdown: [(word: String, isCorrect: Bool, score: Int)] = []
        var totalScoreSum = 0
        
        for (index, targetWord) in targetWords.enumerated() {
            let matchedSpokenWord: String?
            if index < spokenWords.count {
                matchedSpokenWord = spokenWords[index]
            } else if spokenWords.contains(targetWord) {
                matchedSpokenWord = targetWord
            } else {
                matchedSpokenWord = nil
            }
            
            let similarity: Double
            if let spoken = matchedSpokenWord {
                similarity = calculateStringSimilarity(str1: targetWord, str2: spoken)
            } else {
                similarity = 0.0
            }
            
            let wordScore = Int(similarity * 100)
            totalScoreSum += wordScore
            breakdown.append((word: targetWord, isCorrect: wordScore >= 75, score: wordScore))
        }
        
        let calculatedAverage = targetWords.isEmpty ? 0 : (totalScoreSum / targetWords.count)
        let feedback: String
        switch calculatedAverage {
        case 85...100:
            feedback = "Luar biasa! Pengucapan Anda sangat natural dan akurat."
        case 70..<85:
            feedback = "Bagus sekali! Hampir sempurna, perhatikan artikulasi beberapa suku kata."
        case 50..<70:
            feedback = "Cukup baik. Dengarkan kembali audio referensi dan ulangi pelan-pelan."
        default:
            feedback = "Perlu latihan lagi. Coba dengarkan audio contoh dan perhatikan pergerakan lidah/bibir."
        }
        
        self.latestScore = PronunciationScore(
            overallScore: calculatedAverage,
            recognizedText: spokenText,
            targetText: targetText,
            feedbackMessage: feedback,
            wordBreakdown: breakdown
        )
    }
    
    // Levenshtein distance based string similarity (0.0 to 1.0)
    private func calculateStringSimilarity(str1: String, str2: String) -> Double {
        if str1 == str2 { return 1.0 }
        if str1.isEmpty || str2.isEmpty { return 0.0 }
        
        let a = Array(str1)
        let b = Array(str2)
        var dist = [[Int]](repeating: [Int](repeating: 0, count: b.count + 1), count: a.count + 1)
        
        for i in 0...a.count { dist[i][0] = i }
        for j in 0...b.count { dist[0][j] = j }
        
        for i in 1...a.count {
            for j in 1...b.count {
                if a[i - 1] == b[j - 1] {
                    dist[i][j] = dist[i - 1][j - 1]
                } else {
                    dist[i][j] = min(dist[i - 1][j] + 1, dist[i][j - 1] + 1, dist[i - 1][j - 1] + 1)
                }
            }
        }
        
        let maxLength = max(a.count, b.count)
        let distance = dist[a.count][b.count]
        return max(0.0, 1.0 - (Double(distance) / Double(maxLength)))
    }
}
